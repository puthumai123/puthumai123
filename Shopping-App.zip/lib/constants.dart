import 'package:flutter/material.dart';

const kTextColor = (Colors.black);
const kTextLightColor = (Colors.black45);

const kDefaultPadding = 20.0;
